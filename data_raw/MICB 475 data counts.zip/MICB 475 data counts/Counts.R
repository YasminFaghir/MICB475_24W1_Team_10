# count ph values

count_acidic <- nrow(subset(wl_data, ph == "acidic"))     
print(count_acidic)
# 66 acidic

count_neutral <- nrow(subset(wl_data, ph == "neutral"))   
print(count_neutral)
# 31 neutral

count_basic <- nrow(subset(wl_data, ph == "basic"))   
print(count_basic)
# 95 basic

# count calcium values

calcium_high <- nrow(subset(wl_data, calcium == "high"))   
print(calcium_high)
# 0 high

calcium_medium <- nrow(subset(wl_data, calcium == "medium"))   
print(calcium_medium)
# 186 medium

calcium_low <- nrow(subset(wl_data, calcium == "low"))   
print(calcium_low)
# 6 low

# count total_nitrogen_percent

nitrogen_high <- nrow(subset(wl_data, total_nitrogen_percent == "high"))   
print(nitrogen_high)
# 54 high

nitrogen_medium <- nrow(subset(wl_data, total_nitrogen_percent == "medium"))   
print(nitrogen_medium)
# 0 medium

nitrogen_low <- nrow(subset(wl_data, total_nitrogen_percent == "low"))   
print(nitrogen_low)
# 138 low

# count total_carbon_percent

carbon_high <- nrow(subset(wl_data, total_carbon_percent == "high"))   
print(carbon_high)
# 0 high

carbon_medium <- nrow(subset(wl_data, total_carbon_percent == "medium"))   
print(carbon_medium)
# 134 medium

carbon_low <- nrow(subset(wl_data, total_carbon_percent == "low"))   
print(carbon_low)
# 58 low

# count respiration

respiration_high <- nrow(subset(wl_data, respiration == "high"))   
print(respiration_high)
# 112 high 

respiration_medium <- nrow(subset(wl_data, respiration == "medium"))   
print(respiration_medium)
# 0 medium

respiration_low <- nrow(subset(wl_data, respiration == "low"))   
print(respiration_low)
# 80 low